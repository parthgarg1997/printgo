package com.parthgarg.printgo;

import java.io.File;

public class Resourses {


    static String File_name,Vendor="amity",CheckSum;
    static int Amount,No_page;
    static  Boolean Colored;
    static File pdfUri;
    static String order_no;
    static String email;
    static String phone_no;
    static String cust_id;
}
